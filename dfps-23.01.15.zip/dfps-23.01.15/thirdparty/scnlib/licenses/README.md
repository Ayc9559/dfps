# Third-party Software Licenses

## {fmt}

{fmt} is licensed under the MIT license  
Copyright (c) 2012 - present, Victor Zverovich  
See `fmt.rst` for more

## NanoRange

NanoRange is licensed under the Boost Software License, version 1.0.  
Copyright (c) 2018 Tristan Brindle (tcbrindle at gmail dot com)  
See `nanorange.txt` for more
